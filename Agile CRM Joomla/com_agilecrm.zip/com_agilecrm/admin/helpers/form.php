<?php
/**
 * @author     Agile CRM <info@agilecrm.com>
 * @date       26.10.16
 *
 * @copyright  Copyright (C) 2012 - 2016 agilecrm.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined( '_JEXEC' ) or die( 'Restricted access');
$page = $_REQUEST['view']; 

$agile_email = $email;
$agile_password = $password;?>

<?php if($page == 'landingpages') { ?>
<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/bolt" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template1" class="saveBtn" required type="submit" name="login" value="Login" />
</form>
<form action="https://<?php echo $domain; ?>.agilecrm.com/login#pagebuilder" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template2" class="saveBtn" required type="submit" name="login" value="Login" />
</form>
<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/flatty" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template3" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/pratt" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template4" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/cloud-soft" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template5" class="saveBtn" required type="submit" name="login" value="Login" />
</form>


<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/freelancer" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template6" class="saveBtn" required type="submit" name="login" value="Login" />
</form>


<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/landing-page" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template7" class="saveBtn" required type="submit" name="login" value="Login" />
</form>


<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/lugada" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template8" class="saveBtn" required type="submit" name="login" value="Login" />
</form>


<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/sleek" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template9" class="saveBtn" required type="submit" name="login" value="Login" />
</form>


<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/squad" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template10" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/stylish-portfolio" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template11" class="saveBtn" required type="submit" name="login" value="Login" />
</form>
<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/stylish-portfolio" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template11" class="saveBtn" required type="submit" name="login" value="Login" />
</form>


<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-page-add/superawesome" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-template12" class="saveBtn" required type="submit" name="login" value="Login" />
</form>
<?php } elseif($page=='webrules'){ ?>

<!--web rules -->
<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/information/sleak/sleak.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-sleak" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/information/radiant/radiant.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-radiant" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/confirmation/fullscreen/fullscreen.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-fullscreen" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/confirmation/elegant/elegant.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-elegant" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/bold/bold.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-bold" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/split-message/split-message.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-splitmessage" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/standout/standout.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-standout" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/image-split/image-split.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-imagesplit" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/mouseflow/mouseflow.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-mouseflow" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/peep-out/peep-out.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-peepout" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/minimal/minimal.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-minimal" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/elegant/elegant.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-elegant" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/newsletter/newsletter.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-newsletter" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/pop-out/pop-out.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-pop-out" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/form/valentine/valentine.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-valentine" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/schedule/popout/pop-out.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-popout" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/survey/choice-four/choice-four.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-choicefour" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/survey/choice-multi/choice-multi.html" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-choicemulti" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<form action="https://<?php echo $domain; ?>.agilecrm.com/login#webrules-add/survey/choice-two/choice-two.html
" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $agile_email; ?>" />
<input required type="password" name="password" value="<?php echo $agile_password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-choicetwo" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<?php } else { ?>

   <?php foreach($arrayresult as $webv){  
      $c = count($webv);
           for($i = 0; $i <= $c; $i++) {
               foreach($webv[$i]['list'] as $list){ 
                $link = "https://".$domain.".agilecrm.com/login#formbuilder?template=".$list['id'];
                $id = $list['id'];
                $imgpath = "https://".$domain.".agilecrm.com/misc/formbuilder/templates/".$list['id']."/thumbnail.png";
                 ?>
         <form action="<?php echo $link ; ?>" method="post" target="_blank" style="display: none;">
                <input type="text" required name="email" value="<?php echo $agile_email; ?>" />
                <input required type="text" name="password" value="<?php echo $agile_password; ?>" />
                <input required type="text" name="type" value="agile" />
                <input id="agile-top-button-<?php echo $id ?>" class="saveBtn" required type="submit" name="logind" value="Logind" />
   </form>
          <?php }
             }
         } ?>
<?php } ?>

<script src="https://pubnub.a.ssl.fastly.net/pubnub-3.4.min.js" ></script>
<script>
  // CREATE A PUBNUB OBJECT
  Agile_Pubnub = PUBNUB.init({ 'publish_key' : 'pub-c-e4c8fdc2-40b1-443d-8bb0-2a9c8facd274', 'subscribe_key' : 'sub-c-118f8482-92c3-11e2-9b69-12313f022c90',
      ssl : true, origin : 'pubsub.pubnub.com', });
  Agile_Pubnub.subscribe({ channel : getAgileChannelName(), restore : false, message : function(message, env, channel)
{
    console.log(message);
    var action = message.action;
    var name = message.type;
    if(name== 'WebRule'){
      window.location.href = "?option=com_agilecrm&view=webrules";
    }else if(name== 'LandingPages'){
      window.location.href = "?option=com_agilecrm&view=landingpages";
    }else if(name=='Forms'){
      window.location.href = "?option=com_agilecrm&view=formbuilder";
    }else if(name=='Campaigns'){
      window.location.href = "?option=com_agilecrm&view=emailcampaigns";
    }
}});
 function getAgileChannelName(){  
     return  <?php echo json_encode($rest_api) ?>;
    }
</script>