<?php
/**
 * @author     Agile CRM <info@agilecrm.com>
 * @date       26.10.16
 *
 * @copyright  Copyright (C) 2012 - 2016 agilecrm.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */
 
 defined( '_JEXEC' ) or die( 'Restricted access' );  
 
setlocale(LC_ALL, 'C.UTF-8', 'C'); 
 
jimport( 'joomla.application.component.controller');
JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_agilecrm'.DS.'tables');

class JDownloadsHelper
{   

    /*
     * Configure the Linkbar.
     *
     * @param    string    The name of the active view.
     */
    public static function addSubmenu($vName = 'agilecrm')
    {
        $canDo = self::getActions();
        
        JHtmlSidebar::addEntry( JText::_( 'COM_AGILECRM_HOME' ), 'index.php?option=com_agilecrm&view=dashboard', $vName == 'dashboard');
        JHtmlSidebar::addEntry( JText::_( 'COM_AGILECRM_WEBRULES' ), 'index.php?option=com_agilecrm&view=webrules', $vName == 'webrules');
        JHtmlSidebar::addEntry( JText::_( 'COM_AGILECRM_FORMBUILDERS' ), 'index.php?option=com_agilecrm&view=formbuilder', $vName == 'formbuilder');    
        JHtmlSidebar::addEntry( JText::_( 'COM_AGILECRM_LANDINGPAGES' ), 'index.php?option=com_agilecrm&view=landingpages', $vName == 'landingpages');
        JHtmlSidebar::addEntry( JText::_( 'COM_AGILECRM_EMAILCAMPAIGNS' ), 'index.php?option=com_agilecrm&view=emailcampaigns', $vName == 'emailcampaigns');
        JHtmlSidebar::addEntry( JText::_( 'COM_AGILECRM_WEBSTATS' ), 'index.php?option=com_agilecrm&view=webstats', $vName == 'webstats');
        JHtmlSidebar::addEntry( JText::_( 'COM_AGILECRM_REFERAFREIND' ), 'index.php?option=com_agilecrm&view=referafriend', $vName == 'referafriend');

        JHtmlSidebar::addEntry( JText::_( 'COM_AGILECRM_SETTINGS' ), 'index.php?option=com_agilecrm&view=settings', $vName == 'settings');
    }
    /**
     * Gets a list of the actions that can be performed.
     *
     * @param    int     id
     * @param    string  $assetSection (access section name from access.xml)
     * @return   JObject
     */
    public static function getActions($id = 0, $assetSection = '')
    {
        jimport('joomla.access.access');

        $user    = JFactory::getUser();
        $result    = new JObject;
        
        if (empty($id)){
            $assetName = 'com_agilecrm';
            $section   = 'component';
        } else {
            $assetName = 'com_agilecrm.'.$assetSection.'.'.(int) $id;
            if ( $assetSection != '' ){
                if ($assetSection == 'category'){
                    $section   = 'category';
                } else {
                    $section   = 'download';
                }
            }       
        }
        
        $actions = JAccess::getActions('com_jdownloads', $section);
        foreach ($actions as $action){
                 $result->set($action->name, $user->authorise($action->name, $assetName));
        }
        return $result;        
    }
    
     
    // get the plugin info to view it in the logs table list header
    public static function getLogsHeaderInfo(){
           
    }
    
    // read sum of files for a given cat id
    public static function getSumDownloadsFromCat($catid) {       
       $db = JFactory::getDBO();
       $db->setQuery('SELECT COUNT(*) FROM #__jdownloads_files WHERE cat_id = '.$catid);
       $sum = $db->loadResult();
       return $sum;
    }

    // get the root and the current path from the given cat_dir
    public static function getSplittedCategoryDirectoryPath($cat_dir) {       
        $cat_dir_path = new JObject;
        $cat_dir_path->current = substr(strrchr($cat_dir,"/"),1);
        if (!$cat_dir_path->current){
            $cat_dir_path->current = $cat_dir;
        } else {   
            $path_pos = strrpos ( $cat_dir, "/" );
            $cat_dir_path->root = substr($cat_dir, 0, $path_pos + 1);
        }
        return $cat_dir_path;
    }    
        
    /*
    * Read configuration parameter
    *
    * @return jlistConfig
    */
    public static function buildjlistConfig(){
        $db = JFactory::getDBO(); 

        $jlistConfig = array();
        $db->setQuery("SELECT setting_domain, setting_email FROM #__agilecrm_settings");
        $jlistConfigObj = $db->loadObjectList();
        if(!empty($jlistConfigObj)){
            foreach ($jlistConfigObj as $jlistConfigRow){
                $jlistConfig[$jlistConfigRow->setting_name] = $jlistConfigRow->setting_value;
            }
        }
        return $jlistConfig;
    }
    
    /**
     * Build the array with all finded file informations
     * (Path, Folder name, File name, File size, last update date 
     *
     * @param       string  $dir            path to the folder
     * @param       string  $file           contains the file name
     * @param       string  $onlyDir        contains only the folder name
     * @param       array   $type           search pattern for file types
     * @param       bool    $allFiles       find all files and used not file types filter
     * @param       array   $files          contains the complete folder structure
     * @return      array                   the complete results array
     * 
     */
    public static function buildArray($dir,$file,$onlyDir,$type,$allFiles,$files) {

        $typeFormat = FALSE;
        foreach ($type as $item)
      {
        if (strtolower($item) == substr(strtolower($file), -strlen($item)))
                $typeFormat = TRUE;
        }

        if($allFiles || $typeFormat == TRUE)
        {
            if(empty($onlyDir))
                $onlyDir = substr($dir, -strlen($dir), -1);
            $files[$dir.$file]['path'] = $dir;
            $files[$dir.$file]['file'] = $file;
            $files[$dir.$file]['size'] = self::fsize($dir.$file);
            $files[$dir.$file]['date'] = filemtime($dir.$file);
        }
        return $files;
    }

    /**
    * remove the language tag from a given text and return only the text
    *    
    * @param string     $msg
    */
    public static function getOnlyLanguageSubstring($msg)
    {
        // Get the current locale language tag
        $lang_key   = self::getLangKey();        
        
        // remove the language tag from the text
        $startpos = strpos($msg, '{'.$lang_key.'}') +  strlen( $lang_key) + 2 ;
        $endpos   = strpos($msg, '{/'.$lang_key.'}') ;
        
        if ($startpos !== false && $endpos !== false){
            return substr($msg, $startpos, ($endpos - $startpos ));
        } else {    
            return $msg;
        }    
    }
    
    /**
    * get the current used 'locale' language key 
    *    
    * @return string
    */    
    public static function getLangKey()
    {
        $lang        = JFactory::getLanguage();
        $locale      = $lang->getLocale();
        $lang_code   = null;

        if(empty($locale)){
            $lang_code = 'en-GB';
        } else {
            $lang_tag   = $locale[0];
            $lang_data  = explode('.', $lang_tag);
            $lang_code  = JString::str_ireplace('_', '-', $lang_data[0]);
        }
        return $lang_code;    
    }    
    
    /**
    * Rename older language files before we start the update to 2.5/3.x 
    * 
    * 
    *     
    */
    public static function renameOldLanguageFiles($dir)
    {
        
        if ($handle = dir($dir)) {
            while (false !== ($file = $handle->read())) {
                if (!is_dir($dir.'/'.$file)) {
                      if (strpos($file, 'com_jdownloads') !== false){
                           if (strpos($file, 'en-GB') === false && strpos($file, '.old') === false){ 
                               @rename("$dir/$file", "$dir/$file".'.old');
                           }    
                      }
                } elseif (is_dir($dir.'/'.$file) && $file != '.' && $file != '..') {
                    self::renameOldLanguageFiles($dir.'/'.$file);
                }
            }
            $handle->close();
        }       
    }
    
    /**
     * Method to get the correct db prefix (problem with getTablelist() which always/sometimes has lowercase prefix names in array)
     *
     * @return string
     */
    public static function getCorrectDBPrefix() 
    {
        $db = JFactory::getDBO();

        // get DB prefix string and table list
        $prefix     = $db->getPrefix();
        $prefix_low = strtolower($prefix);
        $tablelist  = $db->getTableList();

        if (!in_array ( $prefix.'assets', $tablelist)) {
            if (in_array ( $prefix_low.'assets', $tablelist)) {
                return $prefix_low;
            } else {
                // assets table not found? 
                return '';
            } 
        } else {
            return $prefix;
        }        

    }
    
    /**
    * Converts a string into Float while taking the given or locale number format into account
    * Used as default the defined separator characters from the Joomla main language ini file (as example: en-GB.ini)  
    * 
    * @param mixed $str
    * @param mixed $dec_point
    * @param mixed $thousands_sep
    * @param mixed $decimals
    * @return mixed
    */
    public static function strToNumber( $str, $dec_point=null, $thousands_sep=null, $decimals = 0 )
    {
        if( is_null($dec_point) || is_null($thousands_sep) ) {
            if( is_null($dec_point) ) {
                $dec_point = JText::_('DECIMALS_SEPARATOR');
            }
            if( is_null($thousands_sep) ) {
                $thousands_sep = JText::_('THOUSANDS_SEPARATOR');
            }
        }
        // in this case use we as default the en-GB format
        if (!$dec_point || $dec_point == 'DECIMALS_SEPARATOR') $dec_point = '.'; 
        if (!$thousands_sep || $thousands_sep == 'THOUSANDS_SEPARATOR') $thousands_sep = ',';
        
        // we will not round a value so we must check it
        if (is_numeric($str) && !is_int($str) && !is_double($str) && $decimals == 0){
            $decimals = 2;
        }         

        $number = number_format($str, $decimals, $dec_point, $thousands_sep);
        return $number;
    }    
    
    /**
    * Compute which date format shall be used for the output
    * 
    * @return mixed
    */
    public static function getDateFormat(){
        
        global $jlistConfig;
        
        $format = array();
        
        // check at first the long format 
        // when defined get the format from the current language
        if ($jlistConfig['global.datetime']){
            $format['long'] = self::getOnlyLanguageSubstring($jlistConfig['global.datetime']);
            if (!$format['long']){
                $format['long'] = JText::_('DATE_FORMAT_LC2');
            }
        } else {
            // format is not defined in configuration so we use a standard format from the language file (LC2)
            $format['long'] = JText::_('DATE_FORMAT_LC2');
        }

        // check now the short format field
        // when defined get the format from the current language
        if ($jlistConfig['global.datetime.short']){
            $format['short'] = self::getOnlyLanguageSubstring($jlistConfig['global.datetime.short']);
            if (!$format['short']){
                $format['short'] = JText::_('DATE_FORMAT_LC4');
            }            
        } else {
            // format is not defined in configuration so we use a standard format from the language file (LC4)
            $format['short'] = JText::_('DATE_FORMAT_LC4');
        }

        return $format;    
    } 
    
    /**
     * Show the feature/unfeature links
     *
     * @param   int      $value      The state value
     * @param   int      $i          Row number
     * @param   boolean  $canChange  Is user allowed to change?
     *
     * @return  string       HTML code
     */
    public static function getFeatureHtml($value = 0, $i, $canChange = true)
    {
        JHtml::_('bootstrap.tooltip');

        // Array of image, task, title, action
        $states = array(
            0 => array('unfeatured', 'downloads.featured', 'COM_JDOWNLOADS_UNFEATURED', 'COM_JDOWNLOADS_TOGGLE_FEATURED'),
            1 => array('featured', 'downloads.unfeatured', 'COM_JDOWNLOADS_FEATURED', 'COM_JDOWNLOADS_TOGGLE_FEATURED'),
        );
        $state = JArrayHelper::getValue($states, (int) $value, $states[1]);
        $icon  = $state[0];

        if ($canChange)
        {
            $html = '<a href="#" onclick="return listItemTask(\'cb' . $i . '\',\'' . $state[1] . '\')" class="btn btn-micro hasTooltip'
                . ($value == 1 ? ' active' : '') . '" title="' . JHtml::tooltipText($state[3]) . '"><span class="icon-' . $icon . '"></span></a>';
        }
        else
        {
            $html = '<a class="btn btn-micro hasTooltip disabled' . ($value == 1 ? ' active' : '') . '" title="'
                . JHtml::tooltipText($state[2]) . '"><span class="icon-' . $icon . '"></span></a>';
        }

        return $html;
    }
    
    /**
     * Remove invalid parts from an e-mail addresses list
     *
     * @param   string   $string     The addresses list
     *
     * @return  string   $string     The cleaned addresses list
     */
    public static function cleanEMailAddresses($string = '')
    {
        // check email addresses
        if ($string){
            $checked_list = '';
            $addresses = explode(';', $string);
            foreach ($addresses as $address){
                if (filter_var($address, FILTER_VALIDATE_EMAIL)){
                    $checked_list .= $address.';';
                }    
            }
            $string = implode(';', explode(';', $checked_list, -1));
        }
        return $string;
    } 
    
    /**
     * Build the footer information part for the backend
     *
     * @param   string   $align      direction
     *
     * @return  string   $footer     the formatted 'info' text block
     */    
    public static function buildBackendFooterText($align = 'center')
    {
        
    }
    
}
?>