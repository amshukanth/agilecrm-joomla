<?php
/**
 * @author     Agile CRM <info@agilecrm.com>
 * @date       26.10.16
 *
 * @copyright  Copyright (C) 2012 - 2016 agilecrm.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * Agile CRM Config Controller
 *
 */
class jdownloadsControllerdashboard extends jdownloadsController
{

 /**
	 * logic to save the config data
	 *
	 * @access public
	 * @return void
	 */
	public function save() {
 
        JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));
        
        jimport('joomla.filesystem.file');
        jimport('joomla.filesystem.folder'); 

    	if ($task == 'apply'){
            $this->setRedirect( 'index.php?option=com_agilecrm&view=dashboard', $msg );        
        } else {
            $this->setRedirect( 'index.php?option=com_agilecrm', $msg );
        }	
	}  
}
?>