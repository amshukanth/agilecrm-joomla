<?php
/**
 * @package jDownloads
 * @version 2.5  
 * @copyright (C) 2007 - 2013 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * jDownloads Config Controller
 *
 */
class jdownloadsControllerlandingpages extends jdownloadsController
{
	/**
	 * Constructor
	 */
	function __construct()
	{
		parent::__construct();

		// Register Extra task
		$this->registerTask( 'apply', 	'save' );
	}

	/**
	 * logic for cancel the work on configuration
	 *
	 * @access public
	 * @return void
	 */
	public function cancel() {

		$this->setRedirect( 'index.php?option=com_agilecrm' );
	}	

	/**
	 * logic to save the config data
	 *
	 * @access public
	 * @return void
	 */
	public function save() {
 
        JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));
        
        jimport('joomla.filesystem.file');
        jimport('joomla.filesystem.folder'); 
        
		if ($task == 'apply'){
            $this->setRedirect( 'index.php?option=com_agilecrm&view=landingpages', $msg );        
        } else {
            $this->setRedirect( 'index.php?option=com_agilecrm', $msg );
        }	
	}  
}
?>