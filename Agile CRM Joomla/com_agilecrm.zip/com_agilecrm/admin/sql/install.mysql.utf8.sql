	CREATE TABLE IF NOT EXISTS `#__agilecrm_settings` (
	  `id` int(11) NOT NULL AUTO_INCREMENT,
	  `setting_domain` varchar(64) NOT NULL DEFAULT '',
	  `setting_email` varchar(64) NOT NULL DEFAULT '',
	  `setting_password` varchar(64) NOT NULL DEFAULT '',
	  `setting_rest_api_key` varchar(64) NOT NULL DEFAULT '',
	  `setting_js_api_key` varchar(64) NOT NULL DEFAULT '',
	  `setting_webstats` varchar(64) NOT NULL DEFAULT '',
	  `setting_webrules` varchar(64) NOT NULL DEFAULT '',
	  PRIMARY KEY (`id`)
	) ENGINE=InnoDB  DEFAULT CHARSET=utf8;	 
	