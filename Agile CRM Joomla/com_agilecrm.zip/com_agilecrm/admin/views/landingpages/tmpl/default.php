<?php
/**
 * @package Agile CRM
 * @version 2.5  
 * @copyright (C) 2007 - 2013 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * Agile CRM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
 
defined('_JEXEC') or die('Restricted access');

global $jlistConfig, $jversion; 

JHtml::_('behavior.tooltip');

if (version_compare( $jversion->RELEASE,  '3.4', 'ge' ) == FALSE ) {
    // is not 3.4 or newer - so we must use mootols
    JHTML::_('behavior.formvalidation'); 
} else {
    JHtml::_('behavior.formvalidator'); //Joomla >= 3.4 jQuery
} 

jimport( 'joomla.html.html.tabs' );
$canDo      = JDownloadsHelper::getActions();
// Get a db connection.
$db = JFactory::getDbo();
// Create a new query object.
$query = $db->getQuery(true);
$query->select($db->quoteName(array('id','setting_domain', 'setting_email', 'setting_password', 'setting_rest_api_key','setting_js_api_key')));
$query->from($db->quoteName('#__agilecrm_settings'));
// Reset the query using our newly populated query object.
$db->setQuery($query); 
// Load the results as a list of stdClass objects (see later for more options on retrieving data).
$results = $db->loadObjectList();
foreach ($results as $value => $key){
   $id = $key->id;
   $domain = $key->setting_domain;
   $email = $key->setting_email;
   $password = $key->setting_password;
   $rest_api= $key->setting_rest_api_key;
   $js_api = $key->setting_js_api_key;
} ?>
<?php if($rest_api) { ?>
<?php if (!empty( $this->sidebar)) : ?>
    <div id="j-sidebar-container" class="span2">
        <?php echo $this->sidebar; ?>
    </div>
    <div id="j-main-container" class="span10">
<?php else : ?>
    <div id="j-main-container">
<?php endif;
require (JPATH_ROOT.'/administrator/components/com_agilecrm/helpers/form.php');
require (JPATH_ROOT.'/administrator/components/com_agilecrm/helpers/curlwrap.php');
?>
<form action="https://<?php echo $domain; ?>.agilecrm.com/login#landing-pages" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $email; ?>" />
<input required type="password" name="password" value="<?php echo $password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-send" class="saveBtn" required type="submit" name="login" value="Login" />
</form>

<div id="features">
<div id="agilewrapper" style="padding: 0px 15% 0px 24%;">
<?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/agile-crm.png'."'  title='Agile Crm logo'/>";?>
</div>
<form action="" method="post"><input type="hidden" name="featuresform" value="featuresform">
<div class="mainLeftbox">
<div id="my-content-id_landing">
<h3 class="font-thin h3">Template</h3>
<div class=""><div class="langing-img">
<?php
 echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/landingpage_main.png'."' class='contentimage'  title='Landing Page' width='95%'/>";
?>
<div>
            <a class="btn btn-sm btn-default landingPageTemplateSelect" onclick="document.getElementById('agile-top-button-template2').click();return false;" href="#">Go</a>
        </div></div></div>

</div>
<?php
        if($domain != "" && $email != "" && $rest_api != ""){
           define("AGILE_USER_EMAIL",$email);
           define("AGILE_REST_API_KEY",$rest_api);
           define("AGILE_DOMAIN",$domain);
           $result = curl_wrap("landingpages", null, "GET", "application/json");
            if (version_compare(PHP_VERSION, '5.4.0', '>=') && !(defined('JSON_C_VERSION') && PHP_INT_SIZE > 4)) {
            $result = json_decode($result,false, 512, JSON_BIGINT_AS_STRING);
            } else {
            $result = json_decode($result,false);
            }
           echo "<div class='crm-form-list'>"; ?>
             <div class='formbilder'><div class='add-forms'><a class='more' onclick="document.getElementById('agile-top-button-send').click();return false;" target='_blank' href='#'>Create Landing Pages</a>
             <a onclick='window.location.reload();' title="Refresh" class='reload more'>&#x21bb;</a></div></div>
           <?php $i = 1;
           if(count($result) > 0){ ?>
              <div class="formbilder">
            <table class="wp-list-table widefat plugins" id="form_builder_list">
                   <thead>
                     <th scope="col" id="name" class="manage-column column-name column-primary">S.No.</th>
                       <th scope="col" id="name" class="manage-column column-name column-primary">Name</th>
                       <th scope="col" id="name" class="manage-column column-description">Preview</th>  
                     </tr>
                   </thead>
                   <tbody id="the-list">
                   <?php foreach($result as $k => $v){ ?>
                    
                   <?php echo "<tr><th><strong>".$i.".</strong></th><th>".$v->name."</th>"; ?>
                   
                  <th><?php echo "<a target='_blank'  id='preview' href='https://".$domain.".agilecrm.com/landing/".$v->id."'> <img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/preview.png'."' /></a>"; ?> </th></tr>
                 
                  <?php                
                   $i++;
               } ?>
                </tbody>
                 </table>
                 </div>
              <?php }else{ ?>
              <div class="formbilder">
                 <table class="wp-list-table widefat plugins" id="form_builder_list">
                   <thead>
                     <th scope="col" id="name" class="manage-column column-name column-primary">SNo</th>
                       <th scope="col" id="name" class="manage-column column-name column-primary">Name</th>
                       <th scope="col" id="description" class="manage-column column-description">Preview</th>  
                     </tr>
                   </thead>
              <?php echo "<tr ><th id='count' colspan='3'>Sorry, you dont have any Landing Pages yet.</th></tr>";?>
                   </tbody>
                 </table>
               </div>
              <?php 
               }
              ?>
              
           <?php 
        }
?>
</div>
</div>
<div class="mainrightbox">
  <div class="box-right">   
  <div id="my-content-id_webrules">
<h3 class="font-thin h3">Landing Page</h3>
<p>Landing pages are your lead magnet - a web page created to gather leads online. Create a landing page in Agile CRM and link it from your website, email messages or online ads.</p>
 <?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/landing.png'."' class='contentimage'  title='Landing Page' width='95%'/>"; ?> 
 <p>Add a form to your landing page to gather visitor details, create contacts in Agile CRM automatically, and nurture them using campaigns.</p>
</div>     
            <h3 class="m-t-none h4 m-b-sm">How to use Landing Pages?</h3>
      <div>
      Landing page is your lead magnet - a web page created to gather leads online. Create a landing page in Agile and link it from your website, email messages or online ads. Add a Form to your landing page to gather visitor details, create Contacts in Agile automatically and nature them using Campaigns.
      </div>
      <h4 class="m-t-none h4 m-b-sm">What are Landing Pages?</h4>
     <p>
      The Landing Page Builder helps create high converting landing pages in Agile CRM. With Agile's rich and customizable templates, drag & drop designer features, web forms, responsive designs and code editor, experience a new level in building high quality landing pages.</p>
      <a href='https://www.agilecrm.com/landing-page' target='_blank' class='fb-read'>Read more</a>
     </div>
 </div>
</form>
 </div>
<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery("#features input").click(function(){
        jQuery("#features form").submit();
    });
});
</script>
</div>
<?php } else{ ?>

<script>
        window.location.href = "?option=com_agilecrm&view=settings";
</script>

<?php }
?>
