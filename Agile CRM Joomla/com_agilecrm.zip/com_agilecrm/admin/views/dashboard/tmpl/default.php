<?php
/**
 * @package jDownloads
 * @version 2.5  
 * @copyright (C) 2007 - 2013 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
 
defined('_JEXEC') or die('Restricted access');

global $jlistConfig, $jversion; 

JHtml::_('behavior.tooltip');

if (version_compare( $jversion->RELEASE,  '3.4', 'ge' ) == FALSE ) {
    // is not 3.4 or newer - so we must use mootols
    JHTML::_('behavior.formvalidation'); 
} else {
    JHtml::_('behavior.formvalidator'); //Joomla >= 3.4 jQuery
} 

jimport( 'joomla.html.html.tabs' );
$canDo      = JDownloadsHelper::getActions();
// Get a db connection.
$db = JFactory::getDbo();
// Create a new query object.
$query = $db->getQuery(true);
$query->select($db->quoteName(array('id','setting_domain', 'setting_email', 'setting_password', 'setting_rest_api_key','setting_js_api_key','setting_webstats','setting_webrules')));
$query->from($db->quoteName('#__agilecrm_settings'));
// Reset the query using our newly populated query object.
$db->setQuery($query); 
// Load the results as a list of stdClass objects (see later for more options on retrieving data).
$results = $db->loadObjectList();
foreach ($results as $value => $key){
   $id = $key->id;
   $domain = $key->setting_domain;
   $email = $key->setting_email;
   $password = $key->setting_password;
   $rest_api= $key->setting_rest_api_key;
   $js_api = $key->setting_js_api_key;
   $webrules = $key->setting_webrules;
   $webstats = $key->setting_webstats;
}
$webstats = filter_input(INPUT_POST, 'webstats');
$webrules = filter_input(INPUT_POST, 'webrules');
$webrules = intval($webrules);
$webstats = intval($webstats);
if($webstats && $webrules){
$settings->id = $id;
$settings->setting_webstats= $webstats;
$settings->setting_webrules=  $webrules;
// Insert the object into the user profile table.
$result = JFactory::getDbo()->updateObject('#__agilecrm_settings', $settings, 'id');
}

?>
<?php if($rest_api) { ?>
<?php if (!empty( $this->sidebar)) : ?>
    <div id="j-sidebar-container" class="span2">
        <?php echo $this->sidebar; ?>
    </div>
    <div id="j-main-container" class="span10">
<?php else : ?>
    <div id="j-main-container">
<?php endif;?>
<div id="features">
<div id="agilewrapper" style="text-align:center">
<?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/agile-crm.png'."'  title='Agile Crm logo'/>";?>
</div>
<script>
(function($) {
setTimeout(function(){$('.label-success').slideUp();},3000); 
} ) ( jQuery );
</script>
<?php
    $status = $_GET['status'];
    if($status){
    echo "<div class='label-success' style='color: white;text-align: center;margin-right: 46px;font-size: 15px;font-weight: 500;'>Your settings have been updated successfully.</div>";
    }
    $restatus = $_GET['restatus'];
    if($restatus) {
      echo "<div class='label-success' style='color: white;text-align: center;margin-right: 46px;font-size: 15px;font-weight: 500;'>You have successfully created your Agile CRM account.</div>";
    }
?>
<form action="" method="post" ><input type="hidden" name="featuresform" value="featuresform" />
<input type="hidden" value="<?php echo $id ?>" name="id"/>

<a href="index.php?option=com_agilecrm&view=webrules" style="text-decoration: none;color: #444;">
<div class="box span4">
  <div class="right stripline">
   <div class="header"><?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/webrules.svg'."' width='60px' height='60px' title='Web Rules'/>";?></div>
   <h2 class="heading"><input type="checkbox" name="webrules" value="1" <?php if($webrules== 1){echo " checked "; echo "class='checked'";} ?> />Web Rules</h2>
   <h5>Web Rules automate actions in response to user activity on your website.</h5>
   <a href="index.php?option=com_agilecrm&view=webrules" class="more">More</a>
  </div>
</div></a>
<a href="index.php?option=com_agilecrm&view=formbuilder" style="text-decoration: none;color: #444;">
<div class="box span4">
  <div class="right stripline">
    <div class="header"><?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/form.svg'."' width='60px' height='60px' title='Form Builder'/>";?></div>
    <div class="left">
    </div>
    <h2 class="heading">Form Builder</h2>
   <h5>Agile helps you create your custom Web Rules at ease and place it on your website.</h5>
   <a href="index.php?option=com_agilecrm&view=formbuilder" class="more">More</a>
   </div> 
 </div></a>
<a href="index.php?option=com_agilecrm&view=landingpages" style="text-decoration: none;color: #444;"> 
   <div class="box span4">
   <div class="right stripline">
   <div class="header"><?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/landing.svg'."' width='60px' height='60px' title='Landing Pages'/>";?></div>
   <div class="left">
   </div>
   <h2 class="heading">Landing Pages</h2>
   <h5>The Landing Page Builder helps create high  converting landing pages.</h5>
   <a href="index.php?option=com_agilecrm&view=landingpages" class="more">More</a>
 </div>
</div> </a>
<a href="index.php?option=com_agilecrm&view=emailcampaigns" style="text-decoration: none;color: #444;">
  <div class="box span4">
   <div class="right stripline">
    <div class="header"><?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/mail.svg'."' width='60px' height='60px' title='Email Campaigns'/>";?></div>
    <div class="left">
    </div>
    <h2 class="heading">Email Campaigns</h2>
    <h5>Send newsletters and track performance with Agile CRM's email marketing tools.</h5>
    <a href="index.php?option=com_agilecrm&view=emailcampaigns" class="more">More</a>
   </div>
</div> </a>
<a href="index.php?option=com_agilecrm&view=webstats" style="text-decoration: none;color: #444;">
<div class="box span4">
  <div class="right stripline">
     <div class="header"><?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/webstats.svg'."' width='60px' height='60px' title='Web Stats'/>";?></div>
     <h2 class="heading"> <input type="checkbox" name="webstats" value="1" <?php if($webstats== 1){echo " checked "; echo "class='checked'";} ?>/> Web Stats</h2>
    <h5>Agile gives you deep insight into customer behavior and website performance.</h5>
    <a href="index.php?option=com_agilecrm&view=webstats" class="more">More</a>
  </div> 
</div></a> 
<a href="index.php?option=com_agilecrm&view=referafriend" style="text-decoration: none;color: #444;">
  <div class="box span4">
    <div class="right stripline">
    <div class="header"><?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/refer a friend.svg'."' width='60px' height='60px' title='Refer a Friend'/>";?></div>
    <div class="left">
    </div>
    <h2 class="heading">Refer a Friend</h2>
    <h5 style="">Our in-app referral program for all of Agile CRMs users is currently effective.</h5>
    <a style="" class="more"  href="index.php?option=com_agilecrm&view=referafriend">Refer</a>
   </div>
</div></a>
</form>
</div>
<div class="create_account">

<div id="cloud_logo">
<h2>Agile CRM </h2>
<?php echo "<img src='".JURI::root().'/administrator/components/com_agilecrm/assets/images/agilecrm-cloud-png.png'."' title='logo' width='20%'/>"; ?> 
</div>
<div class="create_account_dashborad">
<h4 id="create_content">Complete All-In-One CRM with Marketing, Sales & Service Automation with Telephony, Helpdesk, Web Engagement, Social Media Integration, Email Campaigns, Mobile Marketing and much more.</h4>
<form action="https://<?php echo $domain; ?>.agilecrm.com/login#" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $email; ?>" />
<input required type="password" name="password" value="<?php echo $password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-send" class="saveBtn" required type="submit" name="login" value="Login" />
</form>
<a onclick="document.getElementById('agile-top-button-send').click();return false;" id="agile-top-button" class="btn btn-default" style="" href="https://<?php echo $domain; ?>.agilecrm.com/" target="_blank">Access Agile CRM Account & Set up</a>
</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery("#features input").click(function(){
        jQuery("#features form").submit();
    });
});
</script>
<?php } else{ ?>

<script>
        window.location.href = "?option=com_agilecrm&view=settings";
</script>

<?php }
?>

</div>
