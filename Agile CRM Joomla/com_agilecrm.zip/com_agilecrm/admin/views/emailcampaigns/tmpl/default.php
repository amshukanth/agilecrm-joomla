<?php
/**
 * @package jDownloads
 * @version 2.5  
 * @copyright (C) 2007 - 2013 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
 
defined('_JEXEC') or die('Restricted access');

global $jlistConfig, $jversion; 

JHtml::_('behavior.tooltip');

if (version_compare( $jversion->RELEASE,  '3.4', 'ge' ) == FALSE ) {
    // is not 3.4 or newer - so we must use mootols
    JHTML::_('behavior.formvalidation'); 
} else {
    JHtml::_('behavior.formvalidator'); //Joomla >= 3.4 jQuery
} 

jimport( 'joomla.html.html.tabs' );
$canDo      = JDownloadsHelper::getActions();
// Get a db connection.
$db = JFactory::getDbo();
// Create a new query object.
$query = $db->getQuery(true);
$query->select($db->quoteName(array('id','setting_domain', 'setting_email', 'setting_password', 'setting_rest_api_key','setting_js_api_key')));
$query->from($db->quoteName('#__agilecrm_settings'));
// Reset the query using our newly populated query object.
$db->setQuery($query); 
// Load the results as a list of stdClass objects (see later for more options on retrieving data).
$results = $db->loadObjectList();
foreach ($results as $value => $key){
   $id = $key->id;
   $domain = $key->setting_domain;
   $email = $key->setting_email;
   $password = $key->setting_password;
   $rest_api= $key->setting_rest_api_key;
   $js_api = $key->setting_js_api_key;
}
?>
<?php if($rest_api) { ?>
<?php if (!empty( $this->sidebar)) : ?>
    <div id="j-sidebar-container" class="span2">
        <?php echo $this->sidebar; ?>
    </div>
    <div id="j-main-container" class="span10">
<?php else : ?>
    <div id="j-main-container">
<?php endif;

require (JPATH_ROOT.'/administrator/components/com_agilecrm/helpers/form.php');
require (JPATH_ROOT.'/administrator/components/com_agilecrm/helpers/curlwrap.php');
?>
<div id="agilewrapper" style="padding: 0px 15% 0px 24%;">
<?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/agile-crm.png'."'  title='Agile Crm logo'/>";?>
</div>
<form action="https://<?php echo $domain; ?>.agilecrm.com/login#workflows" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $email; ?>" />
<input required type="password" name="password" value="<?php echo $password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-send" class="saveBtn" required type="submit" name="login" value="Login" />
</form>
<form action="https://<?php echo $domain; ?>.agilecrm.com/login#workflow-templates" method="post" target="_blank" style="display: none;">
<input type="text" required name="email" value="<?php echo $email; ?>" />
<input required type="password" name="password" value="<?php echo $password; ?>" />
<input required type="hidden" name="type" value="agile" />
<input id="agile-top-button-send1" class="saveBtn" required type="submit" name="login" value="Login" />
</form>
<div id="features">
<form action="" method="post"><input type="hidden" name="featuresform" value="featuresform">
<div class="mainLeftbox" style="border-right: 0px">
 <?php
        if($domain != "" && $email != "" && $rest_api != ""){
           define("AGILE_USER_EMAIL",$email);
           define("AGILE_REST_API_KEY",$rest_api);
           define("AGILE_DOMAIN",$domain);
           $result = curl_wrap("workflows", null, "GET", "application/json");
            if (version_compare(PHP_VERSION, '5.4.0', '>=') && !(defined('JSON_C_VERSION') && PHP_INT_SIZE > 4)) {
            $result = json_decode($result,false, 512, JSON_BIGINT_AS_STRING);
            } else {
            $result = json_decode($result,false);
            }
           echo "<div class='crm-form-list' style='margin-top:30px;'>";
           $i = 1; ?>

           <div class='formbilder'><div class='add-forms'><a class='more' onclick="document.getElementById('agile-top-button-send1').click();return false;" target='_blank' href='#'>Manage Campaigns</a>
          <a onclick='window.location.reload();' title="Refresh" class='reload more'>&#x21bb;</a></div></div>
          <?php  if(count($result) > 0){ 
            //print_r($result);?>
           <div class="formbilder">
              <table class="wp-list-table widefat plugins" id="form_builder_list">
                   <thead>
                     <th scope="col" id="name" class="manage-column column-name column-primary">S.No.</th>
                       <th scope="col" id="name" class="manage-column column-name column-primary">Name</th>
                       <th scope="col" id="name" class="manage-column column-name column-primary"></th>
                     </tr>
                   </thead>
                   <tbody id="the-list">
                   <?php foreach($result as $k => $v){ ?>
                   <?php echo "<tr><th><strong>".$i.".</strong></th><th>".$v->name."</th>"; ?>
                     <th style="text-align: center;"><?php $disable = $v->is_disabled; 
                   if($disable){ ?><span style="background-color: #d9534f;font-weight: normal;text-shadow: 0 1px 0 rgba(0,0,0,0.2);display: inline;padding: .2em .6em .3em;font-size: 75%;font-weight: bold;line-height: 1;color: #fff;text-align: center;white-space: nowrap;vertical-align: baseline;border-radius: .25em;">Disabled</span> <?php }
                   ?></th>  
                  </tr>
                  <?php                
                   $i++;
               }
               ?>
               </tbody>
                 </table>
          </div>
           <?php }else{ ?>
              <div class="formbilder">
                 <table class="wp-list-table widefat plugins" id="form_builder_list">
                   <thead>
                     <th scope="col" id="name" class="manage-column column-name column-primary">S.No</th>
                       <th scope="col" id="name" class="manage-column column-name column-primary">Name</th>
                       <th scope="col" id="description" class="manage-column column-description">Preview</th>  
                     </tr>
                   </thead>
              <?php echo "<tr><th id='count' colspan='3'>Sorry, you dont have any Campaigns yet.</th></tr>";  ?>
                   </tbody>
                 </table>
               </div>
              <?php }
          }
 
?>
</div>
</div>
<div class="mainrightbox" style="border-left: 1px solid #d2d2d2;">
  <div class="box-right">  
  <div id="my-content-id_webrules">
<h3 class="font-thin h3">Campaigns</h3>
<p>Email Campaigns-Track the effectiveness of your email campaigns with real-time notifications for email opens. Email tracking software takes on a better way to give the analytics on campaign emails. </p>
 <?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/email.png'."' class='contentimage' title='Email Campaigns' width='95%'/>"; ?>  
 <p>Enjoy effective templates, personalization, scoring and tagging, advanced reporting, automated responders, real-time alerts and Email A/B testing with Agile's Email Marketing CRM.</p>
</div>
<div id="my-content-id_webrules" style="margin-top:15px;">
<h3 class="font-thin h3">News Letters</h3>
<p>Newsletter-Track the effectiveness of your newsletter campaigns with real-time notifications for email opens. Email tracking software takes on a better way to give the analytics on campaign emails.</p>
<img src="https://cdnsite.agilecrm.com/img/newsletters/campaign-newsletter.png" class='contentimage' alt="News letters" width="95%">
<p> Enjoy effective templates, personalization, scoring and tagging, advanced reporting, automated responders, real-time alerts and Email A/B testing.</p>
</div>      
      <h3 class="m-t-none h4 m-b-sm">Email Campaigns</h3>
      <p>
      Run bulk email campaigns, send newsletters and track performance with Agile CRM's email marketing tools. Enjoy effective templates, personalization, scoring and tagging, advanced reporting, automated responders, real-time alerts and Email A/B testing with Agile's Email Marketing CRM.</p>
     <a href="https://www.agilecrm.com/email-marketing" target="_blank" class="fb-read">Read more</a>
     </div>

 </div>
 
  
        
</form></div>

<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery("#features input").click(function(){
        jQuery("#features form").submit();
    });
});
</script>
</div>
<?php } else{ ?>

<script>
        window.location.href = "?option=com_agilecrm&view=settings";
</script>

<?php }
?>
