<?php
/**
 * @package jDownloads
 * @version 2.5  
 * @copyright (C) 2007 - 2013 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
 
defined('_JEXEC') or die('Restricted access');

global $jlistConfig, $jversion; 

JHtml::_('behavior.tooltip');

if (version_compare( $jversion->RELEASE,  '3.4', 'ge' ) == FALSE ) {
    // is not 3.4 or newer - so we must use mootols
    JHTML::_('behavior.formvalidation'); 
} else {
    JHtml::_('behavior.formvalidator'); //Joomla >= 3.4 jQuery
} 

jimport( 'joomla.html.html.tabs' );
$canDo      = JDownloadsHelper::getActions();
?>

<?php if (!empty( $this->sidebar)) : ?>
    <div id="j-sidebar-container" class="span2">
        <?php echo $this->sidebar; ?>
    </div>
    <div id="j-main-container" class="span10">
<?php else : ?>
    <div id="j-main-container">
<?php endif;
require (JPATH_ROOT.'/administrator/components/com_agilecrm/helpers/curlwrap.php');
$domain =filter_input(INPUT_POST, 'domain');
$email = filter_input(INPUT_POST, 'email');
$password =filter_input(INPUT_POST, 'password');
$id = filter_input(INPUT_POST, 'id');
if($_SERVER["REQUEST_METHOD"] == "POST")
{
if($_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["id"])){
$settings = new stdClass();
define("AGILE_DOMAIN", $domain);  
define("AGILE_USER_EMAIL", $email);
define("AGILE_REST_API_KEY", $password);
$resultapi = curl_wrap("api-key", null, "GET", "application/json");
if (version_compare(PHP_VERSION, '5.4.0', '>=') && !(defined('JSON_C_VERSION') && PHP_INT_SIZE > 4)) {
            $resultapi = json_decode($resultapi,True, 512, JSON_BIGINT_AS_STRING);
            } else {
            $resultapi = json_decode($resultapi,True);
        }
$rest_api = $resultapi['api_key'];
$js_api = $resultapi['js_api_key'];
if($rest_api != ''){
$settings->setting_domain = $domain;
$settings->setting_email= $email;
$settings->setting_password=$password;
$settings->setting_rest_api_key=$rest_api ;
$settings->setting_js_api_key= $js_api;
$settings->setting_webstats= '1';
$settings->setting_webrules=  '1';
// Insert the object into the user profile table.
$result = JFactory::getDbo()->insertObject('#__agilecrm_settings', $settings); ?>
<script>
        window.location.href = "?option=com_agilecrm&view=dashboard&restatus=successful";
</script>
<?php }else{
 $errors = 'Please verify the above details given in the above fields.';  
}
}else{
$settings = new stdClass();
define("AGILE_DOMAIN", $domain);  
define("AGILE_USER_EMAIL", $email);
define("AGILE_REST_API_KEY", $password);
$resultapi = curl_wrap("api-key", null, "GET", "application/json");
$resultapi = json_decode($resultapi, True, 512, JSON_BIGINT_AS_STRING);
$rest_api = $resultapi['api_key'];
$js_api = $resultapi['js_api_key'];
if($rest_api != ''){
$settings->id = $id;
$settings->setting_domain = $domain;
$settings->setting_email= $email;
$settings->setting_password=$password;
$settings->setting_rest_api_key=$rest_api ;
$settings->setting_js_api_key= $js_api;
$settings->setting_webstats= '1';
$settings->setting_webrules=  '1';
// Insert the object into the user profile table.
$result = JFactory::getDbo()->updateObject('#__agilecrm_settings', $settings, 'id'); 

?>
<script>
        window.location.href = "?option=com_agilecrm&view=dashboard&status=successful";
</script>
<?php }else{
 $errors = 'Please verify the above details given in the above fields.';  
}
}
}
$getdoamin = $_GET["domain"];
if($getdoamin){
    $domain = ($_GET["domain"]);
    $email= ($_GET["emailid"]);
    $password= ($_GET["password"]);
    define("AGILE_DOMAIN", $domain);  
    define("AGILE_USER_EMAIL", $email);
    define("AGILE_REST_API_KEY", $password);
    $result = curl_wrap("api-key", null, "GET", "application/json");
    $result = json_decode($result, True, 512, JSON_BIGINT_AS_STRING);
    $rest_api = $result['api_key'];
    $js_api = $result['js_api_key'];    
    $settings->setting_domain = $domain;
    $settings->setting_email= $email;
    $settings->setting_password=$password;
    $settings->setting_rest_api_key=$rest_api ;
    $settings->setting_js_api_key= $js_api;
    $settings->setting_webstats= '1';
    $settings->setting_webrules=  '1';
    // Insert the object into the user profile table.
    $result = JFactory::getDbo()->insertObject('#__agilecrm_settings', $settings);
    ?>
    <script>
    window.location.href = "?option=com_agilecrm&view=dashboard&restatus=successful";
    </script>
    
<?php }


// Get a db connection.
$db = JFactory::getDbo();
// Create a new query object.
$query = $db->getQuery(true);
$query->select($db->quoteName(array('id','setting_domain', 'setting_email', 'setting_password', 'setting_rest_api_key','setting_js_api_key')));
$query->from($db->quoteName('#__agilecrm_settings'));
// Reset the query using our newly populated query object.
$db->setQuery($query); 
// Load the results as a list of stdClass objects (see later for more options on retrieving data).
$results = $db->loadObjectList();
foreach ($results as $value => $key){
   $id = $key->id;
   $domain = $key->setting_domain;
   $email = $key->setting_email;
   $password = $key->setting_password;
   $rest_api= $key->setting_rest_api_key;
   $js_api = $key->setting_js_api_key;
}


?>
<script src="https://pubnub.a.ssl.fastly.net/pubnub-3.4.min.js"></script>
<script>
  // CREATE A PUBNUB OBJECT
    Agile_Pubnub = PUBNUB.init({ 'publish_key' : 'pub-c-e4c8fdc2-40b1-443d-8bb0-2a9c8facd274', 'subscribe_key' : 'sub-c-118f8482-92c3-11e2-9b69-12313f022c90',
      ssl : true, origin : 'pubsub.pubnub.com', });
  Agile_Pubnub.subscribe({ channel : getAgileChannelName(), restore : false, message : function(message, env, channel)
{
    console.log(message);
    var domain = message.domain;
    var emailid =  message.email;
    var password = message.password;
    window.location.href = "?option=com_agilecrm&view=settings&domain=" + domain + "&emailid=" + emailid + "&password=" + password;  

}});
  function getAgileChannelName(){
return document.location.hostname.replace(/\./g, '')+"_CMS";
}
function openAgileRegisterPage(source) {
if(!source)
source = "wordpress";
var windowURL = "https://my.agilecrm.com/register?origin_from=" + source + "&domain_channel=" + getAgileChannelName();
var newwindow = window.open(windowURL,'name','height=600,width=400');
if (window.focus)
{
newwindow.focus();
}
}
</script>
<style>
input.form-control {
    display: block;
    width: 100%;
    height: 21px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,0.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,0.075);
    -webkit-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
}
#email{width:97%;}
#password{width:97%;}
</style>
<div id="features">
<div id="agilewrapper" style="padding: 0px 15% 0px 24%;">
<?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/agile-crm.png'."'  title='Agile Crm logo'/>";?>
</div>
<div class="mainLeftbox" style="margin-top: 26px;">
<div class="well">
<form id="listform" name="listform" action="<?php echo JRoute::_('index.php?option=com_agilecrm&view=settings'); ?>" method="post">
<div class="form-group m-t m-b-none" style="text-align:center;">       
     <h2>Settings</h2>
</div>
<div style="display: table;width: 85%;margin: 0 auto;">
<label>Enter Domain Name</label>
<div class="input-group">
        <input required="" name="domain" class="form-control" id="domain" value="<?php echo $domain ?>" type="text">
      <span class="input-group-addon">.agilecrm.com</span>
</div>
<label>User ID (Email Address)</label><input required="" name="email" class="form-control" id="email" value="<?php echo $email; ?>" type="email">
<label>Password</label><input required="" name="password" class="form-control" id="password" value="<?php echo $password ?>" type="password"> 
<input name="id" class="form-control" id="id" value="<?php echo $id; ?>" type="hidden"> 
&nbsp;<input class="saveBtn" name="save" value="Save" type="submit">
<?php echo '<div style="color: red;text-align:center;margin-top: 15px;">' . $errors . '<br/></div>'; ?>
</div>
</form>
<?php if($email == '') { ?>
<div class="alert alert-warning" style="margin-top:20px;">
          <div style="padding: 27px;display: inline-block;width: 100%;text-align: center;">
              <div class="col-sm-7">
              <div style="opacity:0.7;">Do not have an account with Agile CRM?</div> <div><small class="text-muted">It's fast and free for Ten users</small></div>
              </div>
              <div class="col-sm-5">
               <input type="button" value="Create a new account" onclick="openAgileRegisterPage('wodpress')" class="btn"/>
              </div>
          </div>
</div>
<?php }else { ?>
<div style="margin-top: 20px;"></div>
<div class="form-group m-t m-b-none" style="text-align:center;">       
  </div>
<?php } ?>
</div>
</div>
<div class="mainrightbox">
  <div class="box-right" style="margin-left: 22px;text-align:left;">        
      <h3 class="m-t-none h4 m-b-sm">Benefits of Agile CRM Plugin</h3>
      <ul class="listitem">
     <li>  <!--&#9679;--> Simple to integrate web rule &amp; web stats, no need of coding knowledge.</li>
 <li>  Show real-time web popups to get more info about your website visitors and also increase the number of subscriptions or sign ups</li>
 <li>  Easily integrate customized web forms to your website or app to create or update contacts and log subsquent web activity. </li>
 <li>  Easily integrate attractive landing pages with your website using this plugin.</li>
 <li> Schedule bulk Email Campaigns for newsletters or other marketing activity, with simple drag-and-drop features
 </li>
</ul>
  </div>

 </div>
</div>
</div>
</div>
