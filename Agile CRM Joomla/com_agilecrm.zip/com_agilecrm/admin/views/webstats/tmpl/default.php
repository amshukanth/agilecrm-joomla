<?php
/**
 * @package jDownloads
 * @version 2.5  
 * @copyright (C) 2007 - 2013 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
 
defined('_JEXEC') or die('Restricted access');

global $jlistConfig, $jversion; 

JHtml::_('behavior.tooltip');

if (version_compare( $jversion->RELEASE,  '3.4', 'ge' ) == FALSE ) {
    // is not 3.4 or newer - so we must use mootols
    JHTML::_('behavior.formvalidation'); 
} else {
    JHtml::_('behavior.formvalidator'); //Joomla >= 3.4 jQuery
} 

jimport( 'joomla.html.html.tabs' );
$canDo      = JDownloadsHelper::getActions();
// Get a db connection.
$db = JFactory::getDbo();
// Create a new query object.
$query = $db->getQuery(true);
$query->select($db->quoteName(array('id','setting_domain', 'setting_email', 'setting_password', 'setting_rest_api_key','setting_js_api_key','setting_webstats','setting_webrules')));
$query->from($db->quoteName('#__agilecrm_settings'));
// Reset the query using our newly populated query object.
$db->setQuery($query); 
// Load the results as a list of stdClass objects (see later for more options on retrieving data).
$results = $db->loadObjectList();
foreach ($results as $value => $key){
   $id = $key->id;
   $domain = $key->setting_domain;
   $email = $key->setting_email;
   $password = $key->setting_password;
   $rest_api= $key->setting_rest_api_key;
   $js_api = $key->setting_js_api_key;
   $webrules = $key->setting_webrules;
   $webstats = $key->setting_webstats;
}
$webstats = filter_input(INPUT_POST, 'webstats'); 
$webstats = intval($webstats);
if($webstats){
$settings->id = $id;
$settings->setting_webstats= $webstats;
// Insert the object into the user profile table.
$result = JFactory::getDbo()->updateObject('#__agilecrm_settings', $settings, 'id');
}
 if (!empty( $this->sidebar)) : ?>
    <div id="j-sidebar-container" class="span2">
        <?php echo $this->sidebar; ?>
    </div>
    <div id="j-main-container" class="span10">
<?php else : ?>
    <div id="j-main-container">
<?php endif;?>

<div id="features">
<div id="agilewrapper" style="padding: 0px 15% 0px 24%;">
<?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/agile-crm.png'."'  title='Agile Crm logo'/>";?>
</div>
<form action="" method="post"><input type="hidden" name="featuresform" value="featuresform">
<div class="mainLeftbox">
<?php //echo "<img src='".plugins_url( '/landing.png', __FILE__ )."' class='contentimage'  title='Landing Page' width='95%'/>"; ?> 
 <div class="box" style="width: 90%;margin-left: -2px;">
  <div class="right stripline">
      <div class="header"><?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/webstats.svg'."' width='60px' height='60px' title='Web Stats'/>";?></div>
      <br/> <br/>
     <h5>Get actionable insights into customer acitvity on your site or app and detailed web analytics reports for each of your customers. Learn about the traffic source of your new customers with referral URL reporting in Agile CRM, and show personalized messages to your contacts.</h5>
     <h2 class="heading"><input type="checkbox" name="webstats" value="1" <?php if($webstats== 1){echo " checked "; echo "class='checked'";} ?>/> Web Stats</h2>
  </div> 
</div>
</div>
<div class="mainrightbox">
  <div class="box-right">
             <div id="my-content-id_webrules">
                <h3 class="font-thin h3">WEB STATS</h3>
               <p>Web Stats-By ticking the checkbox, the analytics will be automatically activated and synced with your Agile CRM account. You can view this in your dashboard. Agile's Analytics CRM gives you deep insight into customer behavior and website performance.</p>
                <img src="https://cdnsite.agilecrm.com/img/web-analytics/web-stats.png" alt="web stats" class="contentimage" width="95%"/>
               <p> Agile offers you contact-level analytics and web traffic analysis for companies that are serious about growth.</p>
            </div>        
            <h3 class="m-t-none h4 m-b-sm">WEB STATS</h3>
            <p>Agile's Analytics CRM gives you deep insight into customer behavior and website performance. Agile offers you contact-level analytics and web traffic analysis for companies that are serious about growth.</p>
        <p>You can use javascript API to track page views on your site, add / delete contacts from your website or blog directly. Copy and paste the below code in your webpage's HTML just before the </BODY> tag to enable tracking / API methods.</p>
        <a href='https://www.agilecrm.com/crm-analytics' target='_blank' class='fb-read'>Read more</a>
     </div>
 </div>
</form>

<div class="clear"></div>

<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery("#features input").click(function(){
        jQuery("#features form").submit();
    });
});
</script>
</div>