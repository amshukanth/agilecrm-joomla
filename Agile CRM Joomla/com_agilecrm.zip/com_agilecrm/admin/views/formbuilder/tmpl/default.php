<?php
/**
 * @package jDownloads
 * @version 2.5  
 * @copyright (C) 2007 - 2013 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
 
defined('_JEXEC') or die('Restricted access');

global $jlistConfig, $jversion; 

JHtml::_('behavior.tooltip');

if (version_compare( $jversion->RELEASE,  '3.4', 'ge' ) == FALSE ) {
    // is not 3.4 or newer - so we must use mootols
    JHTML::_('behavior.formvalidation'); 
} else {
    JHtml::_('behavior.formvalidator'); //Joomla >= 3.4 jQuery
} 

jimport( 'joomla.html.html.tabs' );
$canDo      = JDownloadsHelper::getActions();
$db = JFactory::getDbo();
// Create a new query object.
$query = $db->getQuery(true);
$query->select($db->quoteName(array('id','setting_domain', 'setting_email', 'setting_password', 'setting_rest_api_key','setting_js_api_key')));
$query->from($db->quoteName('#__agilecrm_settings'));
// Reset the query using our newly populated query object.
$db->setQuery($query); 
// Load the results as a list of stdClass objects (see later for more options on retrieving data).
$results = $db->loadObjectList();
//print_r($results);
foreach ($results as $value => $key){
   $id=$key->id;
    $domain=$key->setting_domain;
    $email=$key->setting_email;
    $password = $key->setting_password;
    $rest_api = $key->setting_rest_api_key;
    $jsapikey = $key->setting_js_api_key;

}
?>
<?php if($rest_api) { ?>

<?php if (!empty( $this->sidebar)) : ?>
    <div id="j-sidebar-container" class="span2">
        <?php echo $this->sidebar; ?>
    </div>
    <div id="j-main-container" class="span10">
<?php else : ?>
    <div id="j-main-container">
<?php endif;?>
<style>
.modalDialog {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.8);
    z-index: 99999;
    opacity:0;
    -webkit-transition: opacity 400ms ease-in;
    -moz-transition: opacity 400ms ease-in;
    transition: opacity 400ms ease-in;
    pointer-events: none;
}
.modalDialog:target {
    opacity:1;
    pointer-events: auto;
}
.modalDialog > div {
    width: 400px;
    position: relative;
    margin: 3% auto;
    padding: 5px 22px 13px 20px;
    background: #fff;
    height: 500px;
    z-index: 100050;
    -webkit-box-shadow: 0 3px 6px rgba( 0, 0, 0, 0.3 );
    box-shadow: 0 3px 6px rgba( 0, 0, 0, 0.3 );
    overflow-x: scroll;

}
.close {
    background: #606061;
    color: #FFFFFF;
    line-height: 25px;
    position: absolute;
    right: 3px;
    text-align: center;
    top: 4px;
    width: 24px;
    text-decoration: none;
    font-weight: bold;
    -webkit-border-radius: 12px;
    -moz-border-radius: 12px;
    border-radius: 12px;
    -moz-box-shadow: 1px 1px 3px #000;
    -webkit-box-shadow: 1px 1px 3px #000;
    box-shadow: 1px 1px 3px #000;
}
.close:hover {
    background: #00d9ff;
}
</style>
<div id="features">
<div id="agilewrapper" style="padding: 0px 15% 0px 24%;">
<?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/agile-crm.png'."'  title='Agile Crm logo'/>";?>
</div>
<form action="" method="post"><input name="featuresform" value="featuresform" type="hidden">
<div class="mainLeftbox">
<div id="my-content-id_fombuilders">
                </div>
                        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.1/jquery.min.js" type="text/javascript"></script>
        <form action="" method="post" target="_blank" style="display: none;">
                <input type="hidden" required name="email" value="<?php echo $email; ?>" />
                <input required type="hidden" name="password" value="<?php echo $password; ?>" />
                <input required type="hidden" name="type" value="agile" />
                <input id="ddfadsa" class="saveBtn" type="hidden" name="logind" value="Logidnd" />
        </form>
<?php
 require (JPATH_ROOT.'/administrator/components/com_agilecrm/helpers/curlwrap.php');      

        if($domain != "" && $email != "" && $rest_api != ""){
           define("AGILE_USER_EMAIL",$email);
           define("AGILE_REST_API_KEY",$rest_api);
           define("AGILE_DOMAIN",$domain);
              $url = "https://".$domain.".agilecrm.com/misc/formbuilder/templates/templates.json";
              $result = file_get_contents($url);
              $arrayresult = json_decode($result, true, 512, JSON_BIGINT_AS_STRING);
              $hrefwebrules ="https://".$domain.".agilecrm.com/#formbuilder?template";
             $result = curl_wrap("forms", null, "GET", "application/json");
             $result = json_decode($result, false, 512, JSON_BIGINT_AS_STRING);?>
       
        <form action="https://<?php echo $domain; ?>.agilecrm.com/login#forms" method="post" target="_blank" style="display: none;">
        <input type="text" required name="email" value="<?php echo $email; ?>" />
        <input required type="password" name="password" value="<?php echo $password; ?>" />
        <input required type="hidden" name="type" value="agile" />
        <input id="agile-top-button-send" class="saveBtn" type="submit" name="login" value="Login" />
        </form>
           <?php echo "<div class='crm-form-list'>";
          
        require (JPATH_ROOT.'/administrator/components/com_agilecrm/helpers/form.php');
           ?>
           
        <div id="my-content-id_fombuilders">
          <h3 class="font-thin h3">Templates</h3>
             <?php foreach($arrayresult as $webv){  
                $c = count($webv);
                     for($i = 0; $i <= $c; $i++) {
                         foreach($webv[$i]['list'] as $list){ 
                          $link = "https://".$domain.".agilecrm.com/login#formbuilder?template".$list['link'];
                          $id = $list['id'];
                          $imgpath = "https://".$domain.".agilecrm.com/misc/formbuilder/templates/".$list['id']."/thumbnail.png";
                           ?>
                         <div class="landing-icon"><div class="langing-img"> <?php echo"<img src='$imgpath' width='87%'>"; ?> <div>
                      <a class="btn btn-sm btn-default landingPageTemplateSelect" onclick="document.getElementById('agile-top-button-<?php echo $id ?>').click();return false;" target="_blank" >Go</a>
                       
                  </div></div></div>
                    <?php }
                       }
                   } ?>
        </div>

           <div class='formbilder'><div class='add-forms'><a class='more' onclick="document.getElementById('agile-top-button-send').click();return false;" target='_blank' href='#'>Create Forms</a>
           <a onclick='window.location.reload();' title="Refresh" class='reload more'>&#x21bb;</a></div></div>
          <?php  if(count($result) > 0){ 
             $i = 1; 
            //print_r($result);?>
           <div class="formbilder">
              <table class="wp-list-table widefat plugins" id="form_builder_list">
                   <thead>
                     <th scope="col" id="name" class="manage-column column-name column-primary">S.No.</th>
                       <th scope="col" id="name" class="manage-column column-name column-primary">Name</th>
                       <th scope="col" id="description" class="manage-column column-description">Preview</th>  
                     </tr>
                   </thead>
                   <tbody id="the-list">
                   <?php foreach($result as $k => $v){ ?>
                    
                   <?php echo "<tr><th><strong>".$i.".</strong></th><th>".$v->formName."</th>"; ?>
                   

                    <div id="openModal_<?php echo $i ?>" class="modalDialog">
                        <div> <a href="#close" title="Close" class="close">X</a>

                              <h2><?php echo  $v->formHtml ;  ?> </h2>
                         
                            
                        </div>
                    </div>
                  <th><a href="#openModal_<?php echo $i ?>" class="thickbox" id="preview"><?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/preview.png'."' />";?> </a> 
                  </th></tr>
                  <?php                
                   $i++;
               }
               ?>
               </tbody>
                 </table>
          </div>
           <?php }else{ ?>
              <div class="formbilder">
                 <table class="wp-list-table widefat plugins" id="form_builder_list">
                   <thead>
                     <th scope="col" id="name" class="manage-column column-name column-primary">S.No</th>
                       <th scope="col" id="name" class="manage-column column-name column-primary">Form Title</th>
                       <th scope="col" id="description" class="manage-column column-description">Preview</th>  
                     </tr>
                   </thead>
              <?php echo "<tr><th id='count' colspan='3'>Sorry, you dont have any Forms yet.</th></tr>";  ?>
                   </tbody>
                 </table>
               </div>
              <?php }
          }
 
?></div></div>
          </div>
<div class="mainrightbox">
  <div class="box-right">  
  <div id="my-content-id_webrules">
<h3 class="font-thin h3">Form Builder</h3>
<p>Form Builder helps you create your custom web forms easily, and you can place it on your website. Whenever a web visitor fills up the web form, a new contact gets created in Agile CRM, and all the data submitted through the form gets added to the contact page as various attributes </p>
<?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/frombuilder.png'."' class='contentimage'  title='Form Builder' width='95%'/>"; ?>
<p> Name, Company, Phone number, Email, Address, Notes etc. Also, you can keep tracking this contact whenever he visits your website and get his detailed browsing history on the contact page.</p>
</div>      
      <h3 class="m-t-none h4 m-b-sm">What are Forms?</h3>
      <p>
      Forms created using the Form Builder can be placed on your website or app. These Forms are readily linked to your Agile account.  When a visitor fills the form, a Contact is created and subsequent web activity is logged automatically.</p>
      <p>Agile's Form Builder helps you create your custom web forms at ease and place it on your website. Whenever a web visitor fills up the web form, a new contact gets created in Agile and all the data submitted through the form gets added to the contact page as various attributes - Name, Company, Email, Phone no, Address, Notes etc, Also, you can keep tracking this contact whenever he visits your website & get his detailed browsing history on the contact page.</p>
      <a href='https://www.agilecrm.com/web-engagement' target='_blank' class='fb-read'>Read more</a>
     </div>

 </div>
           </div>
</div>

 </form></div>
<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery("#features input").click(function(){
        jQuery("#features form").submit();
    });
});
</script>
<style>
.langing-img img {
    margin-bottom: 10px;
    width: 98%;
    height: 300px;
}
</style>  

</div>

<?php } else{ ?>

<script>
        window.location.href = "?option=com_agilecrm&view=settings";
</script>
<?php }
?>
