<?php
/**
 * @package jDownloads
 * @version 2.5  
 * @copyright (C) 2007 - 2013 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
 
defined('_JEXEC') or die('Restricted access');

global $jlistConfig, $jversion; 

JHtml::_('behavior.tooltip');

if (version_compare( $jversion->RELEASE,  '3.4', 'ge' ) == FALSE ) {
    // is not 3.4 or newer - so we must use mootols
    JHTML::_('behavior.formvalidation'); 
} else {
    JHtml::_('behavior.formvalidator'); //Joomla >= 3.4 jQuery
} 

jimport( 'joomla.html.html.tabs' );
$canDo      = JDownloadsHelper::getActions();
?>

<?php if (!empty( $this->sidebar)) : ?>
    <div id="j-sidebar-container" class="span2">
        <?php echo $this->sidebar; ?>
    </div>
    <div id="j-main-container" class="span10">
<?php else : ?>
    <div id="j-main-container">
<?php endif;?>

<div id="features">
<div id="agilewrapper" style="padding: 0px 15% 0px 24%;">
<?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/agile-crm.png'."'  title='Agile Crm logo'/>";?>
</div>
<form action="" method="post"><input name="featuresform" value="featuresform" type="hidden">
<div class="mainLeftbox">
 <div class="box" style="width: 550px;">
  <div class="right stripline">
    <div class="header"> <?php echo "<img src='".JURI::root().'administrator/components/com_agilecrm/assets/images/refer a friend.svg'."' width='60px' height='60px' title='Refer a Friend'/>";?></div>
    <div class="left">
    </div>
    <h2 class="heading">Refer a Friend</h2>
   <h5>Our customers are our biggest ambassadors. Your love for the product is what makes you refer other awesome clients to us time and again. Not surprisingly, 'word of mouth' has been our most successful source of new customers.
     We’d like to show our gratitude to all of you who take the time to recommend us to your colleagues and partners.</h5>
     </div> 
 </div>
 
 </div>
<div class="mainrightbox">

  <div class="box-right">        
      <h3 class="m-t-none h4 m-b-sm">Refer a Friend</h3>
      <div style="text-align:center;">
                  <div class="refer-friend-desc"> 
                    <p><span>Follow us on Twitter:<br/></span> Follow @agilecrm on Twitter and share about Agile CRM to claim <span>500 extra</span> emails.</p>
                    <p><span>Tweet about us:<br/></span> Mention and retweet about Agile CRM on your Twitter timeline to claim <span>500 extra</span> emails.</p>
                    <p><span>Share on Facebook:<br/></span> Share Agile updates with your Facebook contacts to claim <span>500 extra</span> emails.</p>
                   <p><span>Refer friends:<br/></span> Invite friends to sign up and try Agile CRM to claim <span>500 extra</span> emails per signup.</p>
                   <p><span>Write a blog about us:<br/></span> Blog about Agile CRM and spread the word for <span>2500 extra</span> emails.</p>
                  <a href="https://www.agilecrm.com/blog/agiles-crm-referral-program/" target="_blank" class="fb-read">Read more</a>
                  </div>
                 </div>
      
     </div>

 </div>
 
  
        
</form></div>
<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery("#features input").click(function(){
        jQuery("#features form").submit();
    });
});
</script>
</div>