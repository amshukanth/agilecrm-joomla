<?php
/**
 * @package jDownloads
 * @version 2.5  
 * @copyright (C) 2007 - 2013 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

/**
 * Config View
 *
 */
class jdownloadsViewwebrules extends JViewLegacy
{
    /**
     * config view display method
     * @return void
     **/
      function display($tpl = null)
    {
        require_once JPATH_COMPONENT.'/helpers/jdownloadshelper.php';
        JDownloadsHelper::addSubmenu('webrules');
        $this->addToolbar();
        $this->sidebar = JHtmlSidebar::render();
        parent::display($tpl);
   }
    
    /**
     * Add the page title and toolbar.
     *
     * 
     */
    protected function addToolbar()
    {
        require_once JPATH_COMPONENT.'/helpers/jdownloadshelper.php';

        $state    = $this->get('State');
        $canDo    = JDownloadsHelper::getActions();
        $user     = JFactory::getUser();
        $PLdataDir        = JURI::root() . "administrator/components/com_agilecrm/assets/css/";

        $document = JFactory::getDocument();
        $document->addStyleSheet('../components/com_agilecrm/assets/css/jdownloads_buttons.css');
        $document->addStyleSheet($PLdataDir . 'style.css');
        $document->addScriptDeclaration('function openWindow (url) {
        fenster = window.open(url, "_blank", "width=550, height=480, STATUS=YES, DIRECTORIES=NO, MENUBAR=NO, SCROLLBARS=YES, RESIZABLE=NO");
        fenster.focus();
        }');
         JToolBarHelper::title(JText::_('COM_AGILECRM').': '.JText::_('COM_AGILECRM_BACKEND_WEBRULES'), 'jdconfig');
         JToolBarHelper::help('help.dashboard', true);
              
    }       
}
?>